<?php
$conn=mysqli_connect("localhost","root","","assigmentlog")or die("cannot connect to localhost or database");
?>